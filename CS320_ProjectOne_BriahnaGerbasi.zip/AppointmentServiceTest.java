/**
 * Author: Briahna Gerbasi
 * Course: CS 320
 * Date: 04/05/2026
 * Description: JUnit tests for AppointmentService class
 */
import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {
  
  // tests adding a valid appointment
  @Test
  public void testAddAppointment() {
    AppointmentService service = new AppointmentService();
    Date futureDate = new Date(System.currentTimeMillis() + 1000000);
    Appointment appointment = new Appointment("APT2001", futureDate, "Doctor visit");
    service.addAppointment(appointment);
    assertEquals(appointment, service.getAppointment("APT2001"));
  }
 
  // tests that duplicate appointment IDs are not allowed
  @Test
  public void testDuplicateId() {
    AppointmentService service = new AppointmentService();
    Date futureDate = new Date(System.currentTimeMillis() + 1000000);
    Appointment first = new Appointment("APT2002", futureDate, "Doctor visit");
    Appointment second = new Appointment("APT2002", futureDate, "Dentist visit");
    service.addAppointment(first);
    assertThrows(IllegalArgumentException.class, () -> {
      service.addAppointment(second);
    });
  }
  
  // tests deleting an appointment
  @Test
  public void testDeleteAppointment() {
    AppointmentService service = new AppointmentService();
    Date futureDate = new Date(System.currentTimeMillis() + 1000000);
    Appointment appointment = new Appointment("APT2003", futureDate, "Doctor visit");
    service.addAppointment(appointment);
    service.deleteAppointment("APT2003");
    assertNull(service.getAppointment("APT2003"));
  }
}