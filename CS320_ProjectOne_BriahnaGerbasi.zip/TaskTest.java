/**
 * Author: Briahna Gerbasi
 * Course: CS 320
 * Date: 03/29/2026
 * 
 * These are unit tests for the Task class.
 */
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

  @Test
  public void testCreateTask(){
    Task task = new Task("CS320A1", "Write journal", "Finish the unit testing journal response");

    assertEquals("CS320A1", task.getTaskId());
    assertEquals("Write journal", task.getName());
    assertEquals("Finish the unit testing journal response", task.getDescription());
  }
  @Test
  public void testTaskIdTooLong(){
    assertThrows(IllegalArgumentException.class, () -> {
      new Task("CS320TASK99", "Write journal", "Finish the unit testing journal response");
    });
  }
  @Test
  public void testTaskIdNull(){
    assertThrows(IllegalArgumentException.class, () -> {
      new Task(null, "Write journal", "Finish the unit testing journal response");
    });
  }
  @Test
  public void testTaskNameTooLong(){
    assertThrows(IllegalArgumentException.class, () -> {
      new Task("MOD4TASK", "Complete the full software testing journal","Finish the journal response");
    });
  }
  @Test
  public void testTaskNameNull(){
    assertThrows(IllegalArgumentException.class, () -> {
      new Task("MOD4TASK", null, "Finish the journal response");
    });
  }
  @Test
  public void testTaskDescriptionTooLong(){
    assertThrows(IllegalArgumentException.class, () -> {
      new Task("TASK400","Write code",
      "This description is definitely too long for the limit in this task class");
    });
  }
  @Test
  public void testTaskDescriptionNull(){
    assertThrows(IllegalArgumentException.class, () -> {
      new Task("TASK400", "Write code", null);
    });
  }
  @Test
  public void testUpdateTaskName(){
    Task task = new Task("LAB2401", "Old title", "Work on the coding milestone");
    task.setName("New title");
    assertEquals("New title", task.getName());
  }
  @Test
  public void testSetDescription() {
    Task task = new Task("LAB2402", "Study notes", "Old description");
    task.setDescription("Updated description");
    assertEquals("Updated description", task.getDescription());
  }
}