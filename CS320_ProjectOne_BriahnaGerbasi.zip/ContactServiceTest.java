import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    @Test
    public void testAddContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "John", "Smith", "1234567890", "123 Main St");

        service.addContact(contact);

        assertEquals("John", service.getContact("12345").getFirstName());
    }

    @Test
    public void testAddDuplicateContactId() {
        ContactService service = new ContactService();
        Contact contact1 = new Contact("12345", "John", "Smith", "1234567890", "123 Main St");
        Contact contact2 = new Contact("12345", "Jane", "Jones", "0987654321", "456 Oak Ave");

        service.addContact(contact1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(contact2);
        });
    }

    @Test
    public void testDeleteContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "John", "Smith", "1234567890", "123 Main St");

        service.addContact(contact);
        service.deleteContact("12345");

        assertThrows(IllegalArgumentException.class, () -> {
            service.getContact("12345");
        });
    }

    @Test
    public void testUpdateFirstName() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "John", "Smith", "1234567890", "123 Main St");

        service.addContact(contact);
        service.updateFirstName("12345", "Jane");

        assertEquals("Jane", service.getContact("12345").getFirstName());
    }

    @Test
    public void testUpdateLastName() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "John", "Smith", "1234567890", "123 Main St");

        service.addContact(contact);
        service.updateLastName("12345", "Jones");

        assertEquals("Jones", service.getContact("12345").getLastName());
    }

    @Test
    public void testUpdatePhone() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "John", "Smith", "1234567890", "123 Main St");

        service.addContact(contact);
        service.updatePhone("12345", "0987654321");

        assertEquals("0987654321", service.getContact("12345").getPhone());
    }

    @Test
    public void testUpdateAddress() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "John", "Smith", "1234567890", "123 Main St");

        service.addContact(contact);
        service.updateAddress("12345", "456 Oak Ave");

        assertEquals("456 Oak Ave", service.getContact("12345").getAddress());
    }

    @Test
    public void testDeleteNonexistentContact() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteContact("99999");
        });
    }

    @Test
    public void testUpdateNonexistentContact() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateFirstName("99999", "Jane");
        });
    }
}