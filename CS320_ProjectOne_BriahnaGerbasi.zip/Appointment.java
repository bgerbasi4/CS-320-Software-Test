/**
 * Author: Briahna Gerbasi
 * Course: CS 320
 * Date: 04/05/2026
 * Description:This class creates an Appointment object with validation
 */
import java.util.Date;

public class Appointment {
  // unique ID (cannot be changed)
  private final String appointmentId;
  
  // appointment date (must not be in the past)
  private Date appointmentDate;

  // description of appointment
  private String description;

  // constructor
   public Appointment(String appointmentId, Date appointmentDate, String description) {
    if (appointmentId == null || appointmentId.length() > 10){
      throw new IllegalArgumentException("Invalid appointment ID");
    }
    if (appointmentDate == null || appointmentDate.before(new Date())){
      throw new IllegalArgumentException("Invalid appointment date");
    }
    if (description == null || description.length() > 50){
      throw new IllegalArgumentException("Invalid description");
    }
    this.appointmentId = appointmentId;
    this.appointmentDate = appointmentDate;
    this.description = description;
   }
   public String getAppointmentId(){
    return appointmentId;
   }
   public Date getAppointmentDate(){
    return appointmentDate;
   }
   public void setAppointmentDate(Date appointmentDate){
    if (appointmentDate == null || appointmentDate.before(new Date())){
      throw new IllegalArgumentException("Invalid appointment date");
    }
    this.appointmentDate = appointmentDate;
   }
   public String getDescription(){
    return description;
   }
   public void setDescription(String description){
    if (description == null || description.length() > 50){
      throw new IllegalArgumentException("Invalid description");
    }
    this.description = description;
   }
} 