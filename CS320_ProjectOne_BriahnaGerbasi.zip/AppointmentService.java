/**
 * Author: Briahna Gerbasi
 * Course: CS 320
 * Date: 04/05/2026
 * Description: This class manages adding and deleting appointments
 */
import java.util.HashMap;
import java.util.Map;

public class AppointmentService {

  // stores appointments using ID as key
  private Map<String, Appointment> appointments = new HashMap<>();

  // adds a new appointment
  public void addAppointment(Appointment appointment){
    if (appointment == null){
      throw new IllegalArgumentException("Appointment cannot be null");
    }
    if (appointments.containsKey(appointment.getAppointmentId())) {
      throw new IllegalArgumentException("Appointment ID must be unique");
    }
    appointments.put(appointment.getAppointmentId(), appointment);
  }
  // delete an appointment by ID
  public void deleteAppointment(String appointmentId){
    if(!appointments.containsKey(appointmentId)) {
      throw new IllegalArgumentException("Appointment not found");
    }
    appointments.remove(appointmentId);
  }
  // helper method for testing
  public Appointment getAppointment(String appointmentId) {
    return appointments.get(appointmentId);
  }
}