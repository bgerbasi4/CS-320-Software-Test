/**
 * Author: Briahna Gerbasi
 * Course: CS 320
 * Date: 03/29/2026
 * 
 * This class is used to manage tasks
 * It can add, delete, and update tasks by task ID.
 */
import java.util.HashMap;
import java.util.Map;

public class TaskService {
  // stores tasks using the task ID as the key
  private Map<String, Task> taskList = new HashMap<>();
  // add a task to the list
  public void addTask(Task task){
    if (task == null){
      throw new IllegalArgumentException("Task cannot be null");
    }
    if(taskList.containsKey(task.getTaskId())){
      throw new IllegalArgumentException("Task ID already exists");
    }
    taskList.put(task.getTaskId(), task);
  }
  // remove a task by its ID
  public void deleteTask(String taskId){
    if (!taskList.containsKey(taskId)){
      throw new IllegalArgumentException("Task ID not found");
    }
    taskList.remove(taskId);
  }
  // update the name of a task
  public void updateTaskName(String taskId, String newName){
    if(!taskList.containsKey(taskId)) {
      throw new IllegalArgumentException("Task ID not found");
    }
    taskList.get(taskId).setName(newName);
  }
  // update the description of a task
  public void updateTaskDescription(String taskId, String newDescription){
    if(!taskList.containsKey(taskId)){
      throw new IllegalArgumentException("Task ID not found");
    }
    taskList.get(taskId).setDescription(newDescription);
  }
  // return a task by its ID
  public Task getTask(String taskId){
    return taskList.get(taskId);
  }
}