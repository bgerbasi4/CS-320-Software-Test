/**
 * Author: Briahna Gerbasi
 * Course: CS 320
 * Date: 04/05/2026
 * Description: JUnit tests for Appointment class
 */
import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import org.junit.jupiter.api.Test;

public class AppointmentTest {
  
  // tests creating a valid appointment
  @Test
  public void testValidAppointment() {
    Date futureDate = new Date(System.currentTimeMillis() + 1000000);
    Appointment appointment = new Appointment("APT1001", futureDate, "Doctor visit");
    assertEquals("APT1001", appointment.getAppointmentId());
    assertEquals(futureDate, appointment.getAppointmentDate());
    assertEquals("Doctor visit", appointment.getDescription());
  }
  
  // tests that appointment ID cannot be null 
  @Test
  public void testInvalidId() {
    Date futureDate = new Date(System.currentTimeMillis() + 1000000);
    assertThrows(IllegalArgumentException.class, () -> {
      new Appointment(null, futureDate, "Test");
    });
  }
 
  // tests that appointment date cannot be in the past
  @Test
  public void testDateInPast() {
    Date pastDate = new Date(System.currentTimeMillis() - 1000000);
    assertThrows(IllegalArgumentException.class, () -> {
      new Appointment("APT1002", pastDate, "Test");
    });
  }
  
  // tests that description cannot exceed 50 characters 
  @Test
  public void testDescriptionTooLong() {
    Date futureDate = new Date(System.currentTimeMillis() + 1000000);
    assertThrows(IllegalArgumentException.class, () -> {
      new Appointment("APT1003", futureDate, "This description is too long and should fail validation because it exceeds fifty characters.");
    });
  }
  
  // tests updating description with valid input
  @Test
  public void testSetValidDescription() {
    Date futureDate = new Date(System.currentTimeMillis() + 1000000);
    Appointment appointment = new Appointment("APT1004", futureDate, "Doctor visit");
    appointment.setDescription("Dentist visit");
    assertEquals("Dentist visit", appointment.getDescription());
  }
}