/**
 * Author: Briahna Gerbasi
 * Course: CS 320
 * Date: 03/29/2026
 * 
 * These are unit tests for the TaskService class.
 */
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {
  @Test
  public void testAddSingleTask(){
    TaskService service = new TaskService();
    Task task = new Task("DISC100", "Reply post", "Write one reply for discussion board");
    service.addTask(task);
    assertEquals(task, service.getTask("DISC100"));
  }
  @Test
  public void testAddMultipleTasks() {
    TaskService service = new TaskService();
    Task firstTask = new Task("READ300", "Read chapter", "Read chapter 3 before class");
    Task secondTask = new Task("CODE410", "Finish code", "Work on the Java task service");
    service.addTask(firstTask);
    service.addTask(secondTask);
    assertEquals(firstTask, service.getTask("READ300"));
    assertEquals(secondTask, service.getTask("CODE410"));
  }
  @Test
  public void testAddDuplicateTaskId() {
    TaskService service = new TaskService();
    Task firstTask = new Task("QUIZ210", "Study quiz", "Review notes for the weekly quiz");
    Task secondTask = new Task("QUIZ210", "Take quiz", "Submit the quiz before Sunday");
    service.addTask(firstTask);
    assertThrows(IllegalArgumentException.class, () -> {
      service.addTask(secondTask);
    });
  }
  @Test
  public void testDeleteTask() {
    TaskService service = new TaskService();
    Task task = new Task("HOME500", "Clean room", "Pick up clothes and vacuum floor");
    service.addTask(task);
    service.deleteTask("HOME500");
    assertNull(service.getTask("HOME500"));
  }
  @Test
  public void testDeleteTaskThatDoesNotExist() {
    TaskService service = new TaskService();
    assertThrows(IllegalArgumentException.class, () -> {
      service.deleteTask("NOTREAL1");
    });
  }
  @Test
  public void testUpdateTaskName() {
    TaskService service = new TaskService();
    Task task = new Task("ASSIGN7", "Old task", "Finish part one of the assignment");
    service.addTask(task);
    service.updateTaskName("ASSIGN7", "Updated task");
    assertEquals("Updated task", service.getTask("ASSIGN7").getName());
  }
  @Test
  public void testUpdateTaskDescription() {
    TaskService service = new TaskService();
    Task task = new Task("ASSIGN8", "Coding", "Old description");
    service.addTask(task);
    service.updateTaskDescription("ASSIGN8", "Updated description for the coding task");
    assertEquals("Updated description for the coding task", service.getTask("ASSIGN8").getDescription());
  }
  @Test
  public void testUpdateTaskThatDoesNotExist() {
    TaskService service = new TaskService();
    assertThrows(IllegalArgumentException.class, () -> {
      service.updateTaskName("MISSING1", "New task");
    });
    assertThrows(IllegalArgumentException.class, () -> {
      service.updateTaskDescription("MISSING1", "New description");
    });
  }
} 