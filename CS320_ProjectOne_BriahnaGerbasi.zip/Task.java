/**
 * Author: Briahna Gerbasi
 * Course: CS 320
 * Date: 03/29/2026
 * 
 * This class creates a task object for the project.
 * A task has an ID, a name, and a description.
 */
public class Task{
  // task ID should not change once the task is created
  private final String taskId;

  // these fields can be updated
  private String name;
  private String description;

  // constructor
  public Task(String taskId, String name, String description){
    if (taskId == null || taskId.length() > 10){
      throw new IllegalArgumentException("Task ID is invalid");
    }
    if (name == null || name.length() > 20){
      throw new IllegalArgumentException("Task name is invalid");
    }
    if (description == null || description.length() > 50){
      throw new IllegalArgumentException("Task description is invalid");
    }
    this.taskId = taskId;
    this.name = name;
    this.description = description;
  }
  // return the task's ID
  public String getTaskId(){
    return taskId;
  }
  // return the task name
  public String getName(){
    return name;
  }
  // return the task description
  public String getDescription(){
    return description;
  }
  // update task name
  public void setName(String name){
    if(name == null || name.length() > 20){
      throw new IllegalArgumentException("Task name is invalid");
    }
    this.name = name;
  }
  // update task description 
  public void setDescription(String description){
    if(description == null || description.length() > 50){
      throw new IllegalArgumentException("Task description is invalid");
    }
    this.description = description;
  }
}